﻿using System;

namespace Maersk.Sorting.Processer
{
    public class Class1
    {
    }
}
