﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Controllers
{
    [ApiController]
    [Route("api/sort/")]
    public class SortController : ControllerBase
    {

        private readonly IBackgroundQueue<SortJob> _queue;
        public SortController(IBackgroundQueue<SortJob> queue)
        {
            _queue = queue;
        }
        /// <summary>
        /// Post data to process in backgroud
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        [HttpPost("EnqueueJob")]
        public ActionResult EnqueueJob([FromBody] int[] values)
        {
            var pendingJob = new SortJob(
                id: Guid.NewGuid(),
                status: SortJobStatus.Pending,
                duration: null,
                input: values,
                output: null);
            _queue.JobsCollection.TryAdd(pendingJob.Id, pendingJob);
            _queue.Enqueue(pendingJob);
            return Ok(pendingJob.Id);

        }

        /// <summary>
        /// Get all the jobs which are running in backgroud
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetAllJobs")]
        public ActionResult<SortJob[]> GetJobs()
        {
            return Ok(_queue.JobsCollection.Values);
        }

        /// <summary>
        /// Get particular job status 
        /// </summary>
        /// <param name="jobId">Pass GUID whatever we got after post response</param>
        /// <returns></returns>
        [HttpGet("{jobId}")]
        public ActionResult<SortJob> GetJob(Guid jobId)
        {
            // TODO: Should return a specific job by ID.
            SortJob retData = null;
            var conversionResult = _queue.JobsCollection.TryGetValue(jobId, out retData);
            if (conversionResult)
            {
                return Ok(retData);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
