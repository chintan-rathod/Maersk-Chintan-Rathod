﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Maersk.Sorting.Api

{
    public class BackgroundWorker : BackgroundService
    {
        private readonly IBackgroundQueue<SortJob> _queue;
        private readonly ILogger<BackgroundWorker> _logger;

        public BackgroundWorker(IBackgroundQueue<SortJob> queue, 
            ILogger<BackgroundWorker> logger)
        {
            _queue = queue;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("{Type} is now running in the background.", nameof(BackgroundWorker));

            await BackgroundProcessing(stoppingToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogCritical(
                "The {Type} is stopping due to a host shutdown, queued items might not be processed anymore.",
                nameof(BackgroundWorker)
            );

            return base.StopAsync(cancellationToken);
        }

        private async Task BackgroundProcessing(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await Task.Delay(500, stoppingToken);
                    var job = _queue.Dequeue();
                    if (job == null) continue;
                    _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);
                    var stopwatch = Stopwatch.StartNew();
                    var output = job.Input.OrderBy(n => n).ToArray();
                    await Task.Delay(5000); // NOTE: This is just to simulate a more expensive operation
                    var duration = stopwatch.Elapsed;
                    var ConvertedObject = new SortJob(id: job.Id, status: SortJobStatus.Completed, duration: duration, input: job.Input, output: output);
                    var result = _queue.JobsCollection.TryRemove(job.Id, out SortJob data);
                    _queue.JobsCollection.TryAdd(job.Id, ConvertedObject);
                    _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);

                }
                catch (Exception ex)
                {
                    _logger.LogError("An error occurred while running job. Exception: {@Exception}", ex.Message);
                }
            }
        }
    }
}